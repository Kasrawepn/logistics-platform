<?php
/**
 * Leistungen
 *
 * Generated from website/services.html by wordpress-theme/build.py — edit the static
 * page and re-run the build instead of editing this file.
 */

/*
Template Name: Leistungen
*/

get_header();
?>

<main id="main">

  <section class="page-hero">
    <div class="page-hero__media" data-parallax="0.1">
      <img src="<?php echo esc_url( aydin_asset( 'img/aydin-trucks.jpg' ) ); ?>" alt="Transportfahrzeuge von Aydın Transport &amp; Logistik" fetchpriority="high">
    </div>
    <div class="page-hero__overlay"></div>
    <div class="container page-hero__inner">
      <nav class="breadcrumb" aria-label="Breadcrumb">
        <a href="<?php echo esc_url( aydin_page_url( 'home' ) ); ?>" data-i18n="common.home">Startseite</a><span>/</span><span aria-current="page" data-i18n="nav.services">Leistungen</span>
      </nav>
      <h1 data-i18n="svc.hero.title">Leistungen rund um Ihre Sendung</h1>
      <p data-i18n="svc.hero.lead">
        Von der einzelnen Palette bis zur regelmäßigen Direktfahrt: Wir übernehmen Transport,
        Termin und Übergabe.
      </p>
    </div>
  </section>

  <!-- ====================================================== TRANSPORTE -->
  <section class="section" id="transporte">
    <div class="container">
      <div class="split">
        <div class="split__text">
          <span class="eyebrow" data-i18n="svc.1.eyebrow">01 · Transporte</span>
          <h2 data-i18n="svc.1.title">Deutschlandweiter Transport</h2>
          <p class="lead" data-i18n="svc.1.lead">
            Wir transportieren für Privat- und Geschäftskunden in ganz Deutschland — mit einem
            3,5-Tonnen-Transporter, der im Stadtverkehr genauso zu Hause ist wie auf der
            Autobahn.
          </p>
          <ul class="feature-list">
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.1.b1"><strong>Verladung mit Sorgfalt</strong> und Sicherung der Sendung für die Fahrt.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.1.b2"><strong>Abholung und Zustellung</strong> im vereinbarten Zeitfenster.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.1.b3"><strong>Kurze Rückmeldung,</strong> wenn sich unterwegs etwas ändert.</span></li>
          </ul>
          <div class="split__actions"><a class="btn btn--navy" href="<?php echo esc_url( aydin_page_url( 'contact', '#quote' ) ); ?>" data-i18n="svc.1.cta">Transport anfragen</a></div>
        </div>
        <div class="split__media" data-reveal="scale">
          <div class="panel-media panel-media--wide img-zoom" data-cursor="Transport" data-i18n-attr="data-cursor:home.s1.title">
            <img src="<?php echo esc_url( aydin_asset( 'img/aydin-van-white.jpg' ) ); ?>" alt="Transporter von Aydın Transport &amp; Logistik" loading="lazy">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================= EXPRESS -->
  <section class="section section--soft" id="express">
    <div class="container">
      <div class="split split--reverse">
        <div class="split__text">
          <span class="eyebrow" data-i18n="svc.2.eyebrow">02 · Express-Lieferungen</span>
          <h2 data-i18n="svc.2.title">Wenn es schnell gehen muss</h2>
          <p class="lead" data-i18n="svc.2.lead">
            Zeitkritische Sendungen nehmen wir kurzfristig an und bringen sie ohne Umwege ans
            Ziel.
          </p>
          <ul class="feature-list">
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.2.b1"><strong>Kurzfristige Annahme</strong> nach telefonischer Absprache.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.2.b2"><strong>Direkte Route</strong> statt Sammellauf.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.2.b3"><strong>Bestätigung der Zustellung</strong> nach der Übergabe.</span></li>
          </ul>
          <div class="split__actions"><a class="btn btn--navy" href="<?php echo esc_url( aydin_page_url( 'contact', '#quote' ) ); ?>" data-i18n="svc.2.cta">Express anfragen</a></div>
        </div>
        <div class="split__media" data-reveal="scale">
          <div class="panel-media panel-media--wide img-zoom" data-cursor="Express" data-i18n-attr="data-cursor:home.s2.title">
            <img src="<?php echo esc_url( aydin_asset( 'img/aydin-team-1.jpg' ) ); ?>" alt="Fahrer von Aydın Transport &amp; Logistik" loading="lazy">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==================================================== DIREKTFAHRTEN -->
  <section class="section" id="direktfahrten">
    <div class="container">
      <div class="split">
        <div class="split__text">
          <span class="eyebrow" data-i18n="svc.3.eyebrow">03 · Direktfahrten</span>
          <h2 data-i18n="svc.3.title">Von A nach B, ohne Umweg</h2>
          <p class="lead" data-i18n="svc.3.lead">
            Ihre Ladung wird nicht umgeladen. Ein Fahrzeug, eine Übergabe, ein Ansprechpartner.
          </p>
          <ul class="feature-list">
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.3.b1"><strong>Ideal für sperrige oder empfindliche Güter,</strong> die keine Zwischenstation vertragen.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.3.b2"><strong>Kein Zwischenlager,</strong> keine unnötige Wartezeit.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.3.b3"><strong>Fester Termin</strong> für Abholung und Zustellung.</span></li>
          </ul>
          <div class="split__actions"><a class="btn btn--navy" href="<?php echo esc_url( aydin_page_url( 'contact', '#quote' ) ); ?>" data-i18n="svc.3.cta">Direktfahrt anfragen</a></div>
        </div>
        <div class="split__media" data-reveal="scale">
          <div class="panel-media panel-media--wide img-zoom" data-cursor="Direktfahrt" data-i18n-attr="data-cursor:home.s3.title">
            <img src="<?php echo esc_url( aydin_asset( 'img/aydin-van-dark.jpg' ) ); ?>" alt="Transporter von Aydın Transport &amp; Logistik auf dem Weg zum Ziel" loading="lazy">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================== KURIER -->
  <section class="section section--deep on-dark" id="kurier">
    <div class="container">
      <div class="split split--reverse">
        <div class="split__text">
          <span class="eyebrow eyebrow--light" data-i18n="svc.4.eyebrow">04 · Kurierdienste</span>
          <h2 data-i18n="svc.4.title">Kurierfahrten nach Absprache</h2>
          <p class="lead" data-i18n="svc.4.lead">
            Für eilige Einzelsendungen und kurzfristige Fahrten stehen wir bereit — auch
            kurzfristig erreichbar.
          </p>
          <ul class="feature-list">
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.4.b1"><strong>Persönliche Übergabe,</strong> quittiert vom Empfänger.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.4.b2"><strong>Einzelsendungen</strong> und kleine Mengen.</span></li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n-html="svc.4.b3"><strong>Deutschlandweit unterwegs.</strong></span></li>
          </ul>
          <div class="split__actions"><a class="btn btn--gold" href="<?php echo esc_url( aydin_page_url( 'contact', '#quote' ) ); ?>" data-i18n="svc.4.cta">Kurier anfragen</a></div>
        </div>
        <div class="split__media" data-reveal="scale">
          <div class="panel-media panel-media--wide img-zoom" data-cursor="Kurier" data-i18n-attr="data-cursor:home.s4.title">
            <img src="<?php echo esc_url( aydin_asset( 'img/aydin-van-white.jpg' ) ); ?>" alt="Transporter von Aydın Transport &amp; Logistik am Standort" loading="lazy">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================== NOTIZEN -->
  <section class="section">
    <div class="container">
      <div class="section-head">
        <div>
          <span class="eyebrow" data-reveal="fade" data-i18n="svc.notes.eyebrow">Gut zu wissen</span>
          <h2 class="section-head__title" data-reveal data-i18n="svc.notes.title">Worauf Sie sich verlassen können</h2>
        </div>
        <p data-reveal data-i18n="svc.notes.lead">
          Transport ist Vertrauenssache. Deshalb arbeiten wir mit klaren Absprachen statt mit
          Kleingedrucktem.
        </p>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.25rem" data-reveal-group="80">
        <article class="card" data-reveal>
          <div class="card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7 3v6c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6Z"/><path d="m9 12 2 2 4-4"/></svg></div>
          <h3 data-i18n="svc.c1.title">Sorgfältige Verladung</h3>
          <p data-i18n="svc.c1.text">Wir sichern Ihre Sendung für die Fahrt — Paletten, Kartons, Möbel und empfindliche Güter.</p>
        </article>
        <article class="card" data-reveal>
          <div class="card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5.4l3.4 2"/></svg></div>
          <h3 data-i18n="svc.c2.title">Klare Absprachen</h3>
          <p data-i18n="svc.c2.text">Sie wissen vor der Fahrt, wann wir kommen und wann wir liefern.</p>
        </article>
        <article class="card" data-reveal>
          <div class="card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6.6 3h3l1.5 3.7-2 1.4a12.4 12.4 0 0 0 5.4 5.4l1.4-2L19.6 13v3a2 2 0 0 1-2.2 2A15.4 15.4 0 0 1 4 4.7 2 2 0 0 1 6 2.5"/></svg></div>
          <h3 data-i18n="svc.c3.title">Ein Ansprechpartner</h3>
          <p data-i18n="svc.c3.text">Vom Angebot bis zur Zustellung sprechen Sie mit derselben Person.</p>
        </article>
        <article class="card" data-reveal>
          <div class="card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v9M9 10h4.5a2 2 0 0 1 0 4H9"/></svg></div>
          <h3 data-i18n="svc.c4.title">Faire Angebote</h3>
          <p data-i18n="svc.c4.text">Der Preis steht vor der Fahrt fest — ohne versteckte Kosten.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="cta-band">
    <div class="cta-band__media" data-parallax="0.08">
      <img src="<?php echo esc_url( aydin_asset( 'img/aydin-trucks.jpg' ) ); ?>" alt="" aria-hidden="true" loading="lazy">
    </div>
    <div class="container cta-band__inner">
      <div class="cta-band__copy">
        <span class="eyebrow eyebrow--light" data-i18n="svc.cta.eyebrow">Nächster Schritt</span>
        <h2 data-i18n="svc.cta.title">Sagen Sie uns, was transportiert werden soll</h2>
        <p style="color:rgba(255,255,255,.74)" data-i18n="svc.cta.text">
          Ein kurzes Telefonat reicht meist, um Umfang, Termin und Preis zu klären.
        </p>
      </div>
      <div class="cta-band__actions">
        <a class="btn btn--gold btn--lg" href="<?php echo esc_url( aydin_page_url( 'contact', '#quote' ) ); ?>" data-i18n="common.quote">Angebot anfordern</a>
        <a class="btn btn--ghost-light btn--lg" href="tel:+491608016659">☎ +49 160 801 66 59</a>
      </div>
    </div>
  </section>

</main>

<?php
get_footer();
